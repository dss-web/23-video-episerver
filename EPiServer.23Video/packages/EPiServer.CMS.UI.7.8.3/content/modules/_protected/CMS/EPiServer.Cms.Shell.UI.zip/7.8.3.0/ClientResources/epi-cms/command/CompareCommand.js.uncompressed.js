define("epi-cms/command/CompareCommand", [
    "dojo/_base/declare",
    "dojo/topic",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.compare",
    // Parent class and mixins
    "epi/shell/command/_Command",
    "epi-cms/_SidePanelsToggleMixin",
    "epi-cms/ApplicationSettings",
    "dijit/Destroyable"
], function(
    declare,
    topic,
    // Resources
    localizations,
    // Parent class and mixins
    _Command,
    _SidePanelsToggleMixin,
    ApplicationSettings,
    Destroyable
) {

    // module:
    //      epi-cms/command/CompareCommand
    // summary:
    //      A command that toggles between the compare view and the previous view when executed.
    return declare([_Command, _SidePanelsToggleMixin, Destroyable], {

        // label: [public] String
        //      The 'compare' text of the command to be used in visual elements.
        label: localizations.label,

        // iconClass: [public] String
        //      The CSS class which represents the icon to be used in visual elements.
        iconClass: "epi-iconCompare",

        // canExecute: [readonly] Boolean
        //      Flag which indicates whether this command is able to be executed.
        canExecute: true,

        // active: [readonly] Boolean
        //      Flag which indicates whether this command is in an active state.
        active: false,

        constructor: function() {
            var self = this;

            this.own(
                topic.subscribe("/epi/cms/action/switcheditmode", function() {
                    self.deactivate();
                }),
                topic.subscribe("/epi/cms/action/eyetoggle", function(enabled) {
                    // Deactivate compare if the view settings are toggle on.
                    if (enabled) {
                        self.deactivate();
                    }
                }),
                topic.subscribe("/epi/shell/action/viewchanged", function(type, args, data) {
                    // Deactivate compare if the view changes something other than compare.
                    var view = data && data.viewName;
                    if (view !== "sidebysidecompare") {
                        self.deactivate();
                    }
                    // Hide the compare command if the new view is a legacy view.
                    self.set("isAvailable", type === "epi-cms/contentediting/PageDataController");
                })
            );
        },

        deactivate: function() {
            if (this.active) {
                this.set("active", false);
                this._restoreSidePanels();
                ApplicationSettings.inCompareDisableDeletion = false;
                topic.publish("/epi/shell/action/changeview/deactivate", "sidebysidecompare");
            }
        },

        _execute: function() {
            this.set("active", !this.active);

            if (this.active) {
                topic.publish("/epi/shell/action/changeview", "sidebysidecompare");
                this._hideSidePanels();

                // We disable the version delete while in compare mode to avoid store sync issues
                // Note:    This is a temporary fix that needs to be adressed in later builds of the
                // Compare version, changes using inCompareDisableDeletion have also been made in:
                // DeleteLanguageBranch.js
                // DeleteVersion.js
                ApplicationSettings.inCompareDisableDeletion = true;
            } else {
                this._restoreSidePanels();
                ApplicationSettings.inCompareDisableDeletion = false;
                topic.publish("/epi/shell/action/changeview/back");
            }
        }
    });
});
