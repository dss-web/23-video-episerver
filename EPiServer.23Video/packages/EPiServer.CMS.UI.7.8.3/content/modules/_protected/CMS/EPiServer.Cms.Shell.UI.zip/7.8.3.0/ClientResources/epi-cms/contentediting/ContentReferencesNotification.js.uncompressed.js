﻿define("epi-cms/contentediting/ContentReferencesNotification", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/dom-construct",
    "dojo/on",
    "dojo/when",
// epi
    "epi",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/contentediting/_ContentEditingNotification",
    "epi-cms/command/BackCommand",
    "epi-cms/widget/sharedContentDialogHandler",
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.notificationbar"
],

function (
// dojo
    array,
    declare,
    event,
    domConstruct,
    on,
    when,
// epi
    epi,
    TypeDescriptorManager,
    _ContentEditingNotification,
    BackCommand,
    sharedContentDialogHandler,
// resources
    resources
) {

    return declare([_ContentEditingNotification], {

        // _backCommand: BackCommand
        _backCommand: null,

        constructor: function (params) {

            this._backCommand = new BackCommand();
        },

        postscript: function () {
            this._storeName = "epi.cms.contentreferences";

            this.inherited(arguments);
        },

        _executeAction: function (/*Object*/value) {
            // summary:
            //      Get content reference
            // tags:
            //      protected, extension

            var typeShouldActAsAsset = TypeDescriptorManager.getValue(value.typeIdentifier, "actAsAnAsset");
            if (!typeShouldActAsAsset) {
                return false;
            }

            return this._store.get(value.contentLink);
        },

        _onExecuteSuccess: function (/*Object*/references) {
            // summary:
            //      Set notification(s) when executed success
            // tags:
            //      protected

            if (!references) {
                this._setNotification(null);
                return;
            }

            var notificationText = domConstruct.create("div");
            if (references.length > 0) {
                notificationText.innerHTML += resources.affect;

                var referencesText = references.length + ' ' + (references.length === 1 ? epi.resources.text.item : epi.resources.text.items),
                    self = this,
                    referenceslink = domConstruct.create("a", { href: "#", innerHTML: referencesText, title: resources.referencestooltip }, notificationText);

                //TODO: Make sure that we remove the handler when item is deleted.
                on(referenceslink, "click", function (evt) {
                    event.stop(evt);
                    self._showReferenceDialog();
                });
            }
            else {
                notificationText.innerHTML += epi.resources.messages.notinuse;
            }

            //to update canExecute on command :'(
            this._backCommand.set("model", {});

            this._setNotification({
                content: notificationText,
                commands: [this._backCommand]
            });
        },

        _showReferenceDialog: function () {
            sharedContentDialogHandler({
                contentData: this.get("invokeActionValue"),
                showToolbar: true,
                mode: sharedContentDialogHandler.mode.show
            });
        }

    });

});