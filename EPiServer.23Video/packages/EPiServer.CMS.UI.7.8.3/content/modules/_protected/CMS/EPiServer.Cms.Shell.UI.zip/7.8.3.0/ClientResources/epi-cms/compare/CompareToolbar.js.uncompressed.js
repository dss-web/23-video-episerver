require({cache:{
'url:epi-cms/compare/template/CompareToolbar.html':"<div class=\"dijit\" role=\"toolbar\" tabIndex=\"${tabIndex}\" data-dojo-attach-point=\"containerNode\">\n    <span data-dojo-attach-point=\"leftVersionSection\" class=\"epi-compare-toolbar__text-wrapper\">\n        <span>${_resources.comparing}</span>\n        <span data-dojo-attach-point=\"leftVersionSelector\"></span>\n\n        <span data-dojo-attach-point=\"leftDate\"></span>\n        <span class=\"epi-secondaryText epi-compare-toolbar__info-text\">${_resources.by}</span>\n        <span data-dojo-attach-point=\"leftBy\"></span>\n    </span>\n    <span data-dojo-attach-point=\"rightVersionSection\" class=\"epi-compare-toolbar__text-wrapper\">\n        <span>${_resources.with}</span>\n        <span data-dojo-attach-point=\"rightVersionSelector\"></span>\n        <span data-dojo-attach-point=\"rightDate\"></span>\n        <span class=\"epi-secondaryText epi-compare-toolbar__info-text\">${_resources.by}</span>\n        <span data-dojo-attach-point=\"rightBy\"></span>\n    </span>\n    <span data-dojo-attach-point=\"messageSection\" class=\"epi-compare-toolbar__text-wrapper\"></span>\n</div>\n"}});
define("epi-cms/compare/CompareToolbar", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/Evented",
    "dojo/topic",

    "dijit/Toolbar",
    "epi/shell/widget/DeferredDropDownButton",

    "epi/datetime",
    "epi/username",
    "epi-cms/version/VersionSelector",
    "epi/shell/TypeDescriptorManager",

    "dojo/text!./template/CompareToolbar.html",
    "epi/i18n!epi/shell/ui/nls/episerver.shared.header",
    "epi/i18n!epi/shell/ui/nls/episerver.cms.compare"
], function (
    declare,
    lang,
    domClass,
    Evented,
    topic,

    Toolbar,
    DeferredDropDownButton,

    datetime,
    username,
    VersionSelector,
    TypeDescriptorManager,

    template,
    localizations,
    compareResources
) {
    // module:
    //      epi-cms/compare/CompareToolbar
    return declare([Toolbar, Evented],{
        // summary:
        //      Compare toolbar.
        // tags:
        //      internal

        region: "top",
        baseClass: "epi-compare-toolbar epi-localToolbar epi-flatToolbar",
        templateString: template,

        _leftVersionSelector: null,
        _rightVersionSelector: null,

        _resources: lang.mixin(localizations, compareResources),

        buildRendering: function() {
            // summary:
            //      Setup the widgets DOM mode based on the template and additionally create the version selectors.
            // tags:
            //      private
            this.inherited(arguments);

            this._leftVersionSelector = this._createVersionSelector("leftVersion", "left");
            this._rightVersionSelector = this._createVersionSelector("rightVersion", "right");

            this._leftButton = new DeferredDropDownButton({
                "class": "epi-chromeless epi-chromeless--with-arrow epi-flat",
                dropDown: this._leftVersionSelector,
                iconClass: "epi-iconVersions"
            }, this.leftVersionSelector);

            this._rightButton = new DeferredDropDownButton({
                "class": "epi-chromeless epi-chromeless--with-arrow epi-flat",
                dropDown: this._rightVersionSelector,
                iconClass: "epi-iconVersions"
            }, this.rightVersionSelector);

            this.own(this._leftVersionSelector,
                this._rightVersionSelector,
                this._leftButton,
                this._rightButton);
        },

        postCreate: function () {
            // summary:
            //      Setup the toolbar contents
            // tags:
            //      protected
            this.inherited(arguments);

            var self = this,
                model = this.model,
                updateMessage = lang.hitch(this, "_updateMessage"),
                updateLeft = function() {
                    var version = model.leftVersion;

                    self._leftVersionSelector.set("contentLink", version.contentLink);
                    self._rightVersionSelector.set("markedContentLink", version.contentLink);

                    self._leftButton.set("label", version.statusName);

                    self.leftBy.textContent = username.toUserFriendlyString(version.savedBy, null, false);
                    self.leftDate.textContent = datetime.toUserFriendlyString(version.savedDate);
                },
                updateRight = function() {
                    var version = model.rightVersion;

                    if (version) {
                        self._rightVersionSelector.set("contentLink", version.contentLink);
                        self._leftVersionSelector.set("markedContentLink", version.contentLink);

                        self._rightButton.set("label", version.statusName);

                        self.rightBy.textContent = username.toUserFriendlyString(version.savedBy, null, false);
                        self.rightDate.textContent = datetime.toUserFriendlyString(version.savedDate);
                    }

                    self._updateSections(version !== null);
                };

            if (model.leftVersion) {
                updateLeft();
            }
            this.own(model.watch("leftVersion", updateLeft));

            if (model.rightVersion) {
                updateRight();
            }
            this.own(model.watch("rightVersion", updateRight));

            // Listen to changes on the typeIdentifier and hasAccess properties of the model and update the message text when they change.
            updateMessage();
            this.own(model.watch("typeIdentifier", updateMessage));
            this.own(model.watch("hasAccess", updateMessage));

            this.own(
                topic.subscribe("/epi/cms/content/statuschange/", lang.hitch(this, function() {
                    // Need to refresh the version selectors when a status change happens since this can affect several versions in the list
                    // and the observer pattern on the store only supports updating the affected version.
                    this._leftVersionSelector.refresh();
                    this._rightVersionSelector.refresh();
                }))
            );
        },

        _updateSections: function (hasRightVersion) {
            // summary:
            //      Update the toolbar sections according to whether we have some version to display in the right part.
            // hasRightVersion:
            //      Whether the right version exists.
            // tags:
            //      private

            // Hide the left and right sections if there is no right version.
            domClass.toggle(this.leftVersionSection, "dijitHidden", !hasRightVersion);
            domClass.toggle(this.rightVersionSection, "dijitHidden", !hasRightVersion);

            // Hide the message section if there is a right version.
            domClass.toggle(this.messageSection, "dijitHidden", hasRightVersion);

            this.emit("versionInformationUpdated");
        },

        _updateMessage: function() {
            // summary:
            //      Update the message displayed in the message section to reflect whether the user has access to see the content,
            //      or whether there is only one version of the content.
            // tags:
            //      private
            this.messageSection.textContent = this.model.hasAccess ?
                TypeDescriptorManager.getResourceValue(this.model.typeIdentifier, "compare.onlyoneversion") :
                this._resources.insufficientpermission;
        },

        _createVersionSelector: function (property, region) {
            // summary:
            //      Creates a drop down button with a version selector as its content.
            // tags:
            //      private

            var model = this.model,
                selector = new VersionSelector({
                    store: model.contentVersionStore,
                    region: region
                });

            this.own(selector.on("change", function(version) {
                // Early exit if the same value is selected to ensure no redundant events are fired on the model.
                if (model.get(property) === version) {
                    return;
                }
                model.set(property, version);
            }));

            return selector;
        }
    });
});
